# Screenshot capture checklist

Capture these from the **running application** after connecting MongoDB and starting both apps. Save PNG files in this folder.

- `01-login.png` — login screen
- `02-dashboard.png` — dashboard with summary cards and sample tasks
- `03-task-list.png` — task list with search/status filter
- `04-task-form.png` — create or edit task screen
- `05-mobile-view.png` — responsive mobile view (browser DevTools device mode)

Use fictional demo data only. Do not show real passwords, tokens, personal email addresses, `.env` values, or database credentials. These screenshots are a required final step and are not included as fabricated proof.
