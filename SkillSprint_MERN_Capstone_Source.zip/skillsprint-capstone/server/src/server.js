import 'dotenv/config';
import app from './app.js';
import { connectDB } from './config/db.js';

const port = process.env.PORT || 5000;
try {
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 24) throw new Error('JWT_SECRET must be set to a random value of at least 24 characters.');
  await connectDB();
  app.listen(port, () => console.log(`SkillSprint API listening on port ${port}`));
} catch (err) {
  console.error(`Server startup failed: ${err.message}`);
  process.exit(1);
}
