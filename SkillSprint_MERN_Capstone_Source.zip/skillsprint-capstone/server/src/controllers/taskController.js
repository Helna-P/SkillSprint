import mongoose from 'mongoose';
import Task from '../models/Task.js';

const fields = ['title', 'description', 'category', 'priority', 'status', 'dueDate'];
function cleanPayload(body) {
  const result = {};
  for (const key of fields) if (Object.hasOwn(body, key)) result[key] = body[key];
  if (typeof result.title === 'string') result.title = result.title.trim();
  if (typeof result.description === 'string') result.description = result.description.trim();
  if (result.dueDate === '') result.dueDate = null;
  return result;
}
function validate(payload, partial = false) {
  if (!partial || Object.hasOwn(payload, 'title')) {
    if (typeof payload.title !== 'string' || !payload.title.trim() || payload.title.length > 120) return 'Title is required and must be at most 120 characters.';
  }
  if (payload.description !== undefined && (typeof payload.description !== 'string' || payload.description.length > 1000)) return 'Description must be at most 1000 characters.';
  if (payload.category !== undefined && !['Study','Project','Internship','Personal'].includes(payload.category)) return 'Choose a valid category.';
  if (payload.priority !== undefined && !['Low','Medium','High'].includes(payload.priority)) return 'Choose a valid priority.';
  if (payload.status !== undefined && !['Pending','In Progress','Completed'].includes(payload.status)) return 'Choose a valid status.';
  if (payload.dueDate !== undefined && payload.dueDate !== null && Number.isNaN(Date.parse(payload.dueDate))) return 'Enter a valid due date.';
  return null;
}

export async function listTasks(req, res, next) {
  try {
    const page = Math.max(1, Number.parseInt(req.query.page, 10) || 1);
    const limit = Math.min(50, Math.max(1, Number.parseInt(req.query.limit, 10) || 20));
    const filter = { user: req.user._id };
    if (req.query.status && req.query.status !== 'all') {
      if (!['Pending','In Progress','Completed'].includes(req.query.status)) return res.status(400).json({ message: 'Invalid status filter.' });
      filter.status = req.query.status;
    }
    if (req.query.search) filter.title = { $regex: String(req.query.search).slice(0, 80).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
    const [tasks, total] = await Promise.all([
      Task.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
      Task.countDocuments(filter)
    ]);
    res.json({ tasks, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
  } catch (err) { next(err); }
}

export async function createTask(req, res, next) {
  try {
    const payload = cleanPayload(req.body);
    const issue = validate(payload);
    if (issue) return res.status(400).json({ message: issue });
    const task = await Task.create({ ...payload, user: req.user._id });
    res.status(201).json({ task });
  } catch (err) { next(err); }
}

export async function getTask(req, res, next) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: 'Task not found.' });
    const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    res.json({ task });
  } catch (err) { next(err); }
}

export async function updateTask(req, res, next) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: 'Task not found.' });
    const payload = cleanPayload(req.body);
    if (!Object.keys(payload).length) return res.status(400).json({ message: 'Provide at least one field to update.' });
    const issue = validate(payload, true);
    if (issue) return res.status(400).json({ message: issue });
    const task = await Task.findOneAndUpdate({ _id: req.params.id, user: req.user._id }, payload, { new: true, runValidators: true });
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    res.json({ task });
  } catch (err) { next(err); }
}

export async function deleteTask(req, res, next) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: 'Task not found.' });
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    res.json({ message: 'Task deleted successfully.' });
  } catch (err) { next(err); }
}
