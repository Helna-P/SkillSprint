import mongoose from 'mongoose';

const taskSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, trim: true, minlength: 1, maxlength: 120 },
  description: { type: String, trim: true, maxlength: 1000, default: '' },
  category: { type: String, enum: ['Study', 'Project', 'Internship', 'Personal'], default: 'Study' },
  priority: { type: String, enum: ['Low', 'Medium', 'High'], default: 'Medium' },
  status: { type: String, enum: ['Pending', 'In Progress', 'Completed'], default: 'Pending', index: true },
  dueDate: { type: Date, default: null }
}, { timestamps: true });

taskSchema.index({ user: 1, createdAt: -1 });
export default mongoose.model('Task', taskSchema);
