import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api', timeout: 12000 });
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('skillsprint_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
api.interceptors.response.use((response) => response, (error) => {
  const message = error.response?.data?.message || (error.code === 'ECONNABORTED' ? 'The server took too long to respond.' : 'Could not connect to the server. Please try again.');
  return Promise.reject(new Error(message));
});
export default api;
