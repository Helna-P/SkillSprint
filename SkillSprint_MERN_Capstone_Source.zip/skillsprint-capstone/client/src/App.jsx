import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import TasksPage from './pages/TasksPage';
import TaskFormPage from './pages/TaskFormPage';

export default function App() {
  return <BrowserRouter><AuthProvider><Routes>
    <Route path="/login" element={<AuthPage mode="login"/>}/><Route path="/register" element={<AuthPage mode="register"/>}/>
    <Route element={<ProtectedRoute/>}><Route element={<Layout/>}><Route path="/dashboard" element={<Dashboard/>}/><Route path="/tasks" element={<TasksPage/>}/><Route path="/tasks/new" element={<TaskFormPage/>}/><Route path="/tasks/:id/edit" element={<TaskFormPage/>}/></Route></Route>
    <Route path="*" element={<Navigate to="/dashboard" replace/>}/>
  </Routes></AuthProvider></BrowserRouter>;
}
