import { useEffect, useState } from 'react';
import { ArrowRight, CheckCircle2, Clock3, ListTodo, Plus, Sparkles, Target } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import TaskCard from '../components/TaskCard';

export default function Dashboard() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const load = () => { setLoading(true); setError(''); api.get('/tasks?limit=50').then(({data}) => setTasks(data.tasks)).catch(e => setError(e.message)).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, []);
  const update = async (task, changes) => { try { const {data} = await api.patch(`/tasks/${task._id}`, changes); setTasks(old => old.map(t => t._id === task._id ? data.task : t)); } catch(e) { setError(e.message); } };
  const remove = async (task) => { if (!window.confirm(`Delete "${task.title}"?`)) return; try { await api.delete(`/tasks/${task._id}`); setTasks(old => old.filter(t => t._id !== task._id)); } catch(e) { setError(e.message); } };
  const pending = tasks.filter(t => t.status === 'Pending').length;
  const progress = tasks.filter(t => t.status === 'In Progress').length;
  const completed = tasks.filter(t => t.status === 'Completed').length;
  const recent = [...tasks].sort((a,b) => new Date(b.createdAt)-new Date(a.createdAt)).slice(0,4);
  return <div className="dashboard-page">
    <section className="welcome-banner"><div className="welcome-copy"><span className="welcome-kicker"><Sparkles size={14}/> YOUR PROGRESS, YOUR PACE</span><h2>Every little step counts.</h2><p>Keep your goals visible, your priorities clear, and your momentum going.</p><Link to="/tasks/new" className="banner-button">Plan a new task <ArrowRight size={16}/></Link></div><div className="banner-art" aria-hidden="true"><div className="art-circle circle-one"/><div className="art-circle circle-two"/><div className="art-card"><Target size={25}/><b>One thing at a time</b><span>Focus on what matters today</span><div className="art-progress"><i/></div></div></div></section>
    <div className="section-heading"><div><span className="eyebrow">AT A GLANCE</span><h2>Your workspace</h2></div><Link to="/tasks" className="text-link">View all tasks <ArrowRight size={15}/></Link></div>
    <section className="stats-grid"><div className="stat-card"><div className="stat-icon lavender"><ListTodo size={20}/></div><span>Total tasks</span><strong>{loading ? '—' : tasks.length}</strong><small>Across all categories</small></div><div className="stat-card"><div className="stat-icon amber"><Clock3 size={20}/></div><span>To do</span><strong>{loading ? '—' : pending}</strong><small>Ready for your attention</small></div><div className="stat-card"><div className="stat-icon blue"><Target size={20}/></div><span>In progress</span><strong>{loading ? '—' : progress}</strong><small>Keep the momentum</small></div><div className="stat-card"><div className="stat-icon mint"><CheckCircle2 size={20}/></div><span>Completed</span><strong>{loading ? '—' : completed}</strong><small>Look how far you've come</small></div></section>
    <section className="task-section"><div className="section-heading"><div><span className="eyebrow">RECENT ACTIVITY</span><h2>Recently added tasks</h2></div><Link to="/tasks/new" className="small-add"><Plus size={16}/> Add task</Link></div>
    {error && <div className="alert-error">{error} <button onClick={load}>Retry</button></div>}
    {loading ? <div className="center-state"><span className="spinner"/> Loading your tasks…</div> : recent.length ? <div className="task-list">{recent.map(task => <TaskCard key={task._id} task={task} onToggle={t => update(t,{status:t.status === 'Completed' ? 'Pending' : 'Completed'})} onDelete={remove}/>)}</div> : <div className="empty-state"><div className="empty-icon"><ListTodo size={25}/></div><h3>Your next win starts here</h3><p>You haven't added any tasks yet. Add one small goal to get started.</p><Link className="primary-button" to="/tasks/new"><Plus size={17}/> Create your first task</Link></div>}</section>
  </div>;
}
