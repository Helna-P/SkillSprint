import { useEffect, useState } from 'react';
import { ListFilter, Plus, Search, SlidersHorizontal } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import TaskCard from '../components/TaskCard';

export default function TasksPage() {
  const [tasks,setTasks] = useState([]); const [loading,setLoading] = useState(true); const [error,setError] = useState('');
  const [status,setStatus] = useState('all'); const [search,setSearch] = useState(''); const [query,setQuery] = useState('');
  const load = () => { setLoading(true); setError(''); api.get('/tasks',{params:{limit:50,status,search:query}}).then(({data})=>setTasks(data.tasks)).catch(e=>setError(e.message)).finally(()=>setLoading(false)); };
  useEffect(()=>{load();},[status,query]);
  const update = async (task, changes) => { try { const {data}=await api.patch(`/tasks/${task._id}`,changes); setTasks(old=>old.map(t=>t._id===task._id?data.task:t)); } catch(e){setError(e.message);} };
  const remove = async (task) => { if(!window.confirm(`Delete "${task.title}"?`)) return; try { await api.delete(`/tasks/${task._id}`); setTasks(old=>old.filter(t=>t._id!==task._id)); } catch(e){setError(e.message);} };
  return <div className="tasks-page"><div className="page-title-row"><div><span className="eyebrow">STAY ON TOP OF IT</span><h2>My tasks</h2><p className="muted">A clear view of what needs doing and what you've achieved.</p></div><Link to="/tasks/new" className="primary-button"><Plus size={17}/> New task</Link></div>
  <div className="filters-bar"><div className="search-box"><Search size={17}/><form onSubmit={e=>{e.preventDefault();setQuery(search.trim());}}><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search tasks…" aria-label="Search tasks"/></form></div><div className="filter-control"><SlidersHorizontal size={16}/><label htmlFor="status-filter">Status</label><select id="status-filter" value={status} onChange={e=>setStatus(e.target.value)}><option value="all">All tasks</option><option>Pending</option><option>In Progress</option><option>Completed</option></select></div></div>
  {error && <div className="alert-error" role="alert">{error} <button onClick={load}>Retry</button></div>}
  {loading ? <div className="center-state"><span className="spinner"/> Loading your tasks…</div> : tasks.length ? <><div className="results-label"><ListFilter size={15}/> {tasks.length} task{tasks.length===1?'':'s'} shown</div><div className="task-list">{tasks.map(task=><TaskCard key={task._id} task={task} onToggle={t=>update(t,{status:t.status==='Completed'?'Pending':'Completed'})} onDelete={remove}/>)}</div></> : <div className="empty-state"><div className="empty-icon"><Search size={24}/></div><h3>No tasks found</h3><p>Try another search or status filter, or create a task to start your list.</p><button className="secondary-button" onClick={()=>{setSearch('');setQuery('');setStatus('all');}}>Clear filters</button></div>}
  </div>;
}
