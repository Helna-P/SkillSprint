import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { BookOpenCheck, ArrowRight, Sparkles } from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function AuthPage({ mode }) {
  const isRegister = mode === 'register';
  const { user, authenticate } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/dashboard" replace/>;
  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setError(''); setBusy(true);
    try { const { data } = await api.post(`/auth/${isRegister ? 'register' : 'login'}`, form); authenticate(data); navigate('/dashboard'); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  return <div className="auth-screen"><div className="auth-visual"><div className="auth-brand"><BookOpenCheck size={25}/> SkillSprint</div><div className="visual-copy"><span className="pill-light"><Sparkles size={14}/> YOUR NEXT CHAPTER STARTS HERE</span><h1>Small steps.<br/><em>Big momentum.</em></h1><p>A calmer way to keep your studies, projects, and internship goals moving forward.</p><div className="visual-note"><div className="note-check">✓</div><div><b>Progress feels good.</b><small>Organise your priorities and celebrate each completed task.</small></div></div></div><div className="auth-visual-foot">Built for students with big plans.</div></div>
  <div className="auth-panel"><div className="auth-form-wrap"><div className="mobile-brand"><BookOpenCheck/> SkillSprint</div><span className="form-kicker">{isRegister ? 'GET STARTED' : 'WELCOME BACK'}</span><h2>{isRegister ? 'Create your account' : 'Sign in to SkillSprint'}</h2><p className="muted">{isRegister ? 'Your personal workspace is just a few details away.' : 'Pick up where you left off and keep moving forward.'}</p>
  <form onSubmit={submit} className="form-stack">{isRegister && <label>Full name<input name="name" value={form.name} onChange={change} placeholder="e.g. Ananya Nair" minLength="2" maxLength="60" required autoComplete="name"/></label>}<label>Email address<input name="email" type="email" value={form.email} onChange={change} placeholder="you@example.com" required autoComplete="email"/></label><label>Password<input name="password" type="password" value={form.password} onChange={change} placeholder={isRegister ? 'At least 8 characters' : 'Enter your password'} minLength={isRegister ? 8 : undefined} required autoComplete={isRegister ? 'new-password' : 'current-password'}/></label>{error && <div className="alert-error" role="alert">{error}</div>}<button className="primary-button full-button" disabled={busy}>{busy ? 'Please wait…' : isRegister ? 'Create account' : 'Sign in'} <ArrowRight size={17}/></button></form>
  <p className="auth-switch">{isRegister ? 'Already have an account?' : 'New to SkillSprint?'} <Link to={isRegister ? '/login' : '/register'}>{isRegister ? 'Sign in' : 'Create an account'}</Link></p><p className="auth-privacy">Your tasks are private to your account.</p></div></div></div>;
}
