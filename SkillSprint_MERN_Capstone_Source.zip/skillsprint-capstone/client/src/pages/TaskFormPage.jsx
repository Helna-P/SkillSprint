import { useEffect, useState } from 'react';
import { ArrowLeft, CalendarDays, Save } from 'lucide-react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api from '../services/api';

const blank = { title:'', description:'', category:'Study', priority:'Medium', status:'Pending', dueDate:'' };
export default function TaskFormPage() {
  const { id } = useParams(); const editing = Boolean(id); const navigate = useNavigate();
  const [form,setForm] = useState(blank); const [loading,setLoading] = useState(editing); const [busy,setBusy] = useState(false); const [error,setError] = useState('');
  useEffect(()=>{ if(editing) api.get(`/tasks/${id}`).then(({data})=>setForm({...data.task,dueDate:data.task.dueDate?new Date(data.task.dueDate).toISOString().slice(0,10):''})).catch(e=>setError(e.message)).finally(()=>setLoading(false)); },[id,editing]);
  const change=e=>setForm({...form,[e.target.name]:e.target.value});
  const submit=async e=>{e.preventDefault();setBusy(true);setError('');const payload={...form,dueDate:form.dueDate||null};try{if(editing)await api.patch(`/tasks/${id}`,payload);else await api.post('/tasks',payload);navigate('/tasks');}catch(e){setError(e.message);}finally{setBusy(false);}};
  if(loading) return <div className="center-state"><span className="spinner"/> Loading task…</div>;
  return <div className="task-form-page"><Link to="/tasks" className="back-link"><ArrowLeft size={16}/> Back to tasks</Link><div className="form-heading"><span className="eyebrow">{editing?'REFINE YOUR PLAN':'MAKE A PLAN'}</span><h2>{editing?'Edit task':'Create a new task'}</h2><p className="muted">{editing?'Update the details and keep your plan relevant.':'Break your goals into manageable steps you can act on.'}</p></div>
  <form className="task-form-card" onSubmit={submit}><div className="form-section-title"><span className="form-section-number">01</span><div><b>Task details</b><small>Give this task a clear name and a little context.</small></div></div>
  <label>Task title <span className="required">*</span><input name="title" value={form.title} onChange={change} placeholder="e.g. Complete capstone documentation" maxLength="120" required autoFocus/><small className="field-hint">Keep it specific and actionable (up to 120 characters).</small></label>
  <label>Description <textarea name="description" value={form.description} onChange={change} placeholder="What does done look like? Add any useful notes…" rows="4" maxLength="1000"/></label>
  <div className="form-section-title second-section"><span className="form-section-number">02</span><div><b>Plan your task</b><small>Set a category, priority, and optional due date.</small></div></div>
  <div className="form-grid"><label>Category<select name="category" value={form.category} onChange={change}><option>Study</option><option>Project</option><option>Internship</option><option>Personal</option></select></label><label>Priority<select name="priority" value={form.priority} onChange={change}><option>Low</option><option>Medium</option><option>High</option></select></label><label>Status<select name="status" value={form.status} onChange={change}><option>Pending</option><option>In Progress</option><option>Completed</option></select></label><label>Due date <span className="optional">(optional)</span><div className="date-input"><CalendarDays size={16}/><input type="date" name="dueDate" value={form.dueDate||''} onChange={change}/></div></label></div>
  {error && <div className="alert-error" role="alert">{error}</div>}<div className="form-actions"><Link to="/tasks" className="secondary-button">Cancel</Link><button className="primary-button" disabled={busy}>{busy?'Saving…':<><Save size={16}/> {editing?'Save changes':'Create task'}</>}</button></div></form></div>;
}
