import { createContext, useContext, useEffect, useState } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  useEffect(() => {
    const token = localStorage.getItem('skillsprint_token');
    if (!token) { setChecking(false); return; }
    api.get('/auth/me').then(({ data }) => setUser(data.user)).catch(() => localStorage.removeItem('skillsprint_token')).finally(() => setChecking(false));
  }, []);
  const authenticate = (data) => { localStorage.setItem('skillsprint_token', data.token); setUser(data.user); };
  const logout = () => { localStorage.removeItem('skillsprint_token'); setUser(null); };
  return <AuthContext.Provider value={{ user, checking, authenticate, logout }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
