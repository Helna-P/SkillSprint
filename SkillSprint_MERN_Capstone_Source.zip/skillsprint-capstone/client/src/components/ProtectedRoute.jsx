import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
export default function ProtectedRoute() {
  const { user, checking } = useAuth();
  if (checking) return <div className="center-state"><span className="spinner" /> Checking your session…</div>;
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}
