import { CalendarDays, Check, Circle, Pencil, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function TaskCard({ task, onDelete, onToggle }) {
  const navigate = useNavigate();
  const due = task.dueDate ? new Date(task.dueDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'No due date';
  return <article className={`task-card ${task.status === 'Completed' ? 'is-complete' : ''}`}>
    <button className={`task-check ${task.status === 'Completed' ? 'checked' : ''}`} onClick={() => onToggle(task)} aria-label={task.status === 'Completed' ? 'Mark pending' : 'Mark completed'}>{task.status === 'Completed' ? <Check size={15}/> : <Circle size={17}/>}</button>
    <div className="task-main"><div className="task-title-row"><h3>{task.title}</h3><span className={`priority priority-${task.priority.toLowerCase()}`}>{task.priority}</span></div>{task.description && <p>{task.description}</p>}<div className="task-meta"><span className="category-tag">{task.category}</span><span><CalendarDays size={14}/>{due}</span><span className={`status status-${task.status.toLowerCase().replace(' ', '-')}`}>{task.status}</span></div></div>
    <div className="task-actions"><button className="icon-button" aria-label="Edit task" onClick={() => navigate(`/tasks/${task._id}/edit`)}><Pencil size={16}/></button><button className="icon-button danger-hover" aria-label="Delete task" onClick={() => onDelete(task)}><Trash2 size={16}/></button></div>
  </article>;
}
