import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { BookOpenCheck, LayoutDashboard, ListTodo, LogOut, Plus, UserRound } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const leave = () => { logout(); navigate('/login'); };
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-icon"><BookOpenCheck size={21}/></span><span>SkillSprint<small>STUDENT WORKSPACE</small></span></div>
      <div className="nav-label">WORKSPACE</div>
      <nav>
        <NavLink to="/dashboard"><LayoutDashboard size={18}/> Overview</NavLink>
        <NavLink to="/tasks"><ListTodo size={18}/> My tasks</NavLink>
      </nav>
      <button className="side-create" onClick={() => navigate('/tasks/new')}><Plus size={18}/> Create a task</button>
      <div className="sidebar-bottom"><div className="avatar">{user?.name?.charAt(0)?.toUpperCase() || 'S'}</div><div className="user-meta"><b>{user?.name}</b><small>{user?.email}</small></div><button className="icon-button" aria-label="Log out" title="Log out" onClick={leave}><LogOut size={17}/></button></div>
    </aside>
    <main className="main-area"><header className="topbar"><div><span className="top-eyebrow">YOUR PERSONAL WORKSPACE</span><h1>Make progress, one task at a time.</h1></div><div className="top-user"><UserRound size={16}/><span>{user?.name}</span></div></header><div className="page-content"><Outlet/></div><footer>SkillSprint <span>·</span> Plan thoughtfully. Learn consistently.</footer></main>
  </div>;
}
