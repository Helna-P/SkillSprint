# SkillSprint — Student Task & Internship Tracker

A full-stack MERN capstone project for students to organise study tasks, internship applications, and project milestones in one place.

## Features
- Register and log in with hashed passwords and JWT authentication.
- Create, view, edit, complete, and delete personal tasks.
- Track task status, priority, category, and due date.
- Dashboard summaries and task search/filter.
- Server-side validation, ownership checks, pagination, central error handling, and rate-limited authentication routes.
- Responsive React interface with loading, empty, success, and error states.

## Stack
MongoDB + Mongoose, Express, Node.js, React + Vite, React Router, Axios, JWT, bcryptjs, Helmet.

## Project structure
```text
skillsprint-capstone/
  client/                 # React + Vite app
    src/
      components/
      context/
      pages/
      services/
      App.jsx
      main.jsx
      styles.css
    .env.example
  server/
    src/
      config/
      controllers/
      middleware/
      models/
      routes/
      app.js
      server.js
    .env.example
  .gitignore
  README.md
```

## Requirements
- Node.js LTS and npm
- Git
- MongoDB local installation or a MongoDB Atlas cluster
- Optional: Postman or Thunder Client

## Run locally
1. Clone this repository and enter its folder.
2. Install server dependencies:
   ```bash
   cd server
   npm install
   ```
3. Copy `server/.env.example` to `server/.env`, then set `MONGODB_URI` and a long random `JWT_SECRET`.
4. Start the API:
   ```bash
   npm run dev
   ```
   The API defaults to `http://localhost:5000`.
5. In a second terminal, install the client:
   ```bash
   cd client
   npm install
   ```
6. Copy `client/.env.example` to `client/.env`. For local development, use `VITE_API_URL=http://localhost:5000/api`.
7. Start the frontend:
   ```bash
   npm run dev
   ```
8. Open the Vite URL shown in the terminal (normally `http://localhost:5173`), register an account, and create tasks.

## Environment variables

### `server/.env`
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://127.0.0.1:27017/skillsprint
JWT_SECRET=replace_with_a_long_random_secret
JWT_EXPIRES_IN=1d
CLIENT_URL=http://localhost:5173
```

### `client/.env`
```env
VITE_API_URL=http://localhost:5000/api
```

Never commit real `.env` files, database credentials, or JWT secrets. The client-side `VITE_` value is public and must contain only the API URL.

## API contract
| Method | Path | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create account |
| POST | `/api/auth/login` | Public | Authenticate |
| GET | `/api/auth/me` | Bearer token | Current profile |
| GET | `/api/tasks?page=1&limit=20&status=all&search=` | Bearer token | List own tasks |
| POST | `/api/tasks` | Bearer token | Create task |
| GET | `/api/tasks/:id` | Bearer token | Get own task |
| PATCH | `/api/tasks/:id` | Bearer token | Update own task |
| DELETE | `/api/tasks/:id` | Bearer token | Delete own task |
| GET | `/api/health` | Public | Health check |

Success responses use JSON. Errors use `{ "message": "..." }`. Invalid input returns 400, unauthenticated requests 401, missing resources 404, duplicate email 409, and unexpected failures 500.

## Test checklist
- Register with valid data; attempt duplicate email.
- Log in with correct and incorrect credentials.
- Verify task endpoints reject requests without a token.
- Create a task with a title; verify empty title is rejected.
- Edit, complete, filter, and delete a task.
- Sign in as a second user and verify the first user's tasks are not visible or editable.
- Check loading, empty, error, and retry states.
- Test mobile layout and keyboard-only navigation.
- Run `npm run build` in `client` and inspect server logs.

## Deployment
- Database: MongoDB Atlas; create a least-privilege database user and restrict network access.
- API: deploy `server` to a Node-capable host. Set `MONGODB_URI`, `JWT_SECRET`, `CLIENT_URL`, `NODE_ENV=production`, and `PORT` in its dashboard.
- Frontend: deploy `client` to a static host. Set `VITE_API_URL` to the deployed API URL plus `/api`.
- Update API CORS `CLIENT_URL` to the exact deployed frontend origin. Enable HTTPS. Configure SPA fallback to `index.html` if your host needs it.
- Re-test register, login, CRUD, deep-link refresh, and browser console after deployment.

## Screenshots for submission
Save real screenshots after running/deploying the app to `docs/screenshots/`:
1. Login / Register
2. Dashboard summary
3. Task list with filters
4. Create/edit task form
5. Mobile responsive view
Do not use fabricated screenshots as proof of a hosted application.

## Known limitations / future improvements
- No email verification or password reset yet.
- JWT is stored in localStorage for this educational MVP; for production, consider secure, HttpOnly cookie sessions and CSRF protections appropriate to that design.
- Automated test suite and role-based admin dashboard can be added later.
- No calendar sync or file attachments in the MVP.

## Submission links
- GitHub repository: TODO — replace with your public repository URL.
- Hosted application: TODO — replace after deployment.
- API URL: TODO — replace after deployment.
